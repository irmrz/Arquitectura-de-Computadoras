# Laboratorio 1 Arquitectura del Computador 2023

Primero hay que crear el acceso directo al directorio de progs, ejecutar:

```bash
cd src
make link
```

Para cargar el programa en el microcontrolador, ejecutar:

```bash
cd src
make compile
```

Luego para verificar que el resultado obtenido en memdump sea el esperado, ejecutar:

```bash
cd src
make compare
```
